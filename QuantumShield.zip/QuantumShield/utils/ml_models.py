import numpy as np
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
import pandas as pd

def anomaly_detection(data):
    """
    Perform anomaly detection on network traffic data.
    
    Args:
        data: Dictionary containing network data
    
    Returns:
        List of detected anomalies
    """
    # Extract connection features for anomaly detection
    connection_features = []
    for conn in data['connections']:
        connection_features.append([
            conn['traffic_volume'],
            1 if conn['is_suspicious'] else 0,
            data['nodes'][conn['source']]['risk_score'],
            data['nodes'][conn['target']]['risk_score']
        ])
    
    # Convert to numpy array
    features = np.array(connection_features)
    
    # If no connections, return empty list
    if len(features) == 0:
        return []
    
    # Standardize features
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(features)
    
    # Use Isolation Forest for anomaly detection
    model = IsolationForest(contamination=0.05, random_state=42)
    predictions = model.fit_predict(scaled_features)
    
    # Get the anomalies (where prediction is -1)
    anomaly_indices = np.where(predictions == -1)[0]
    
    # Prepare anomaly results
    anomalies = []
    for idx in anomaly_indices:
        conn = data['connections'][idx]
        source_node = data['nodes'][conn['source']]
        target_node = data['nodes'][conn['target']]
        
        anomalies.append({
            'source_ip': source_node['ip'],
            'target_ip': target_node['ip'],
            'traffic_volume': conn['traffic_volume'],
            'connection_type': conn['connection_type'],
            'risk_score': (source_node['risk_score'] + target_node['risk_score']) / 2,
            'anomaly_score': model.score_samples(scaled_features[idx].reshape(1, -1))[0]
        })
    
    return anomalies

def cluster_traffic_patterns(data):
    """
    Identify clusters in network traffic patterns.
    
    Args:
        data: Dictionary containing network data
    
    Returns:
        Dictionary with clustering results
    """
    # Extract node and connection information
    traffic_patterns = []
    for node in data['nodes']:
        # Find all connections where this node is a source or target
        outgoing = sum(1 for conn in data['connections'] if conn['source'] == node['id'])
        incoming = sum(1 for conn in data['connections'] if conn['target'] == node['id'])
        
        traffic_patterns.append([
            node['risk_score'],
            outgoing,
            incoming,
        ])
    
    # Convert to numpy array
    patterns = np.array(traffic_patterns)
    
    # If not enough data, return empty results
    if len(patterns) < 5:
        return {'clusters': [], 'cluster_assignments': []}
    
    # Standardize the features
    scaler = StandardScaler()
    scaled_patterns = scaler.fit_transform(patterns)
    
    # Perform DBSCAN clustering
    clustering = DBSCAN(eps=0.5, min_samples=3).fit(scaled_patterns)
    
    # Get cluster labels
    labels = clustering.labels_
    
    # Count number of clusters (ignoring noise which is labeled as -1)
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    
    # Compile results
    results = {
        'clusters': n_clusters,
        'cluster_assignments': labels.tolist(),
        'noise_points': (labels == -1).sum()
    }
    
    return results

def predict_threat_probability(data):
    """
    Predict the probability of a security threat based on network data.
    
    Args:
        data: Dictionary containing network data
    
    Returns:
        Dictionary with threat probabilities
    """
    # Extract features for threat prediction
    suspicious_connections = sum(1 for conn in data['connections'] if conn['is_suspicious'])
    high_risk_nodes = sum(1 for node in data['nodes'] if node['risk_score'] > 70)
    
    # Calculate baseline metrics
    total_connections = len(data['connections'])
    total_nodes = len(data['nodes'])
    
    # Calculate overall threat probabilities
    threat_probability = min(0.95, max(0.05, (
        0.4 * (suspicious_connections / max(1, total_connections)) +
        0.4 * (high_risk_nodes / max(1, total_nodes)) +
        0.2 * (np.random.random() * 0.3)  # Random factor to simulate unpredictability
    )))
    
    # Determine threat level
    if threat_probability < 0.3:
        threat_level = "Low"
    elif threat_probability < 0.6:
        threat_level = "Medium"
    elif threat_probability < 0.8:
        threat_level = "High"
    else:
        threat_level = "Critical"
    
    # Calculate specific threat type probabilities
    threat_types = {
        'DDoS Attack': min(0.95, max(0.05, np.random.beta(2, 5) + 0.2 * threat_probability)),
        'Data Breach': min(0.95, max(0.05, np.random.beta(2, 5) + 0.15 * threat_probability)),
        'Ransomware': min(0.95, max(0.05, np.random.beta(1, 6) + 0.1 * threat_probability)),
        'Quantum Key Attack': min(0.95, max(0.05, np.random.beta(1, 8) + 0.05 * threat_probability)),
    }
    
    return {
        'overall_probability': threat_probability,
        'threat_level': threat_level,
        'threat_types': threat_types
    }
