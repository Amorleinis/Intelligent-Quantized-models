import os
import requests
from datetime import datetime, timedelta

class VulnDBAPI:
    def __init__(self):
        self.base_url = "https://vulndb.cyberriskanalytics.com/api/v1"
        self.headers = {
            "Accept": "application/json",
            "X-API-Key": os.getenv("VULNDB_API_KEY")
        }

    def get_recent_vulnerabilities(self, days_back=7):
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days_back)
            
            params = {
                "date_from": start_date.strftime("%Y-%m-%d"),
                "date_to": end_date.strftime("%Y-%m-%d")
            }
            
            response = requests.get(
                f"{self.base_url}/vulnerabilities",
                headers=self.headers,
                params=params
            )
            
            if response.status_code == 200:
                vulns = response.json().get("vulnerabilities", [])
                return self._format_vulnerabilities(vulns)
            return None
        except Exception as e:
            print(f"Error fetching VulnDB data: {str(e)}")
            return None

    def _format_vulnerabilities(self, vulns):
        formatted_vulns = []
        for vuln in vulns:
            severity = self._calculate_severity(vuln.get("cvss_score", 0))
            formatted_vulns.append([
                vuln.get("reference_id", ""),
                vuln.get("title", "No title available"),
                vuln.get("cvss_score", 0),
                vuln.get("disclosure_date", ""),
                severity,
                vuln.get("cvss_vector", "N/A"),
                self._extract_attack_vector(vuln.get("cvss_vector", ""))
            ])
        return formatted_vulns

    def _calculate_severity(self, score):
        if score >= 9.0:
            return "CRITICAL"
        elif score >= 7.0:
            return "HIGH"
        elif score >= 4.0:
            return "MEDIUM"
        return "LOW"

    def _extract_attack_vector(self, vector):
        if "AV:N" in vector:
            return "NETWORK"
        elif "AV:A" in vector:
            return "ADJACENT_NETWORK"
        elif "AV:L" in vector:
            return "LOCAL"
        elif "AV:P" in vector:
            return "PHYSICAL"
        return "UNKNOWN"
